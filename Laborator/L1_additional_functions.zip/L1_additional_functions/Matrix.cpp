#include "Matrix.h"
#include <exception>
#include <stdexcept>
#include <iostream>

using namespace std;


/**
 * @brief This is the class contractor
 * @param nrLines - the number of lines
 * @param nrCols - the number of columns of the matrix
 */
Matrix::Matrix(int nrLines, int nrCols) {

    /**
 * @details We implement the constructor so that it can initialize the private members
 * values and rowIndexes arrays can be allocated with the initial capacity of
 * columns and the columnPointers can be initialized with the size of columns+1.
 * Also, the first element of columnPointers is set to 0 and the rest are set to size
 * We initialize three dynamic arrays that hold the elements, row indexes and column_vec pointers so we can represent
 * the ccs sparse matrix format. it initializes the matrix with empty elements and column pointers
 */
    this->rows = nrLines; //nr_lines
    this->columns = nrCols; //nr_cols

    this->rowSize = 0; //line_size
    this->rowCapacity = 5; //line_capacity

    //elementsCapacity = 10;
    this->elements = new TElem[this->rowCapacity]{NULL_TELEM};
    this->columnPointers = new int[this->columns + 1]{NULL_TELEM};
    this->rowIndexes = new int[this->rowCapacity]{NULL_TELEM};

}

/**
 * @brief returns the number of rows in the matrix
 * @params  -
 * @Best_case  θ(1)
 * @Medium_case  θ(1)
 * @Total_case θ(1)
 */
int Matrix::nrLines() const {
    return this->rows;
}

/**
 * @brief returns the number of columns in the matrix
 * @params -
 * @Best_case θ(1)
 * @Medium_case θ(1)
 * @Total_case θ(1)
 */
int Matrix::nrColumns() const {
    return this->columns;
}


/**
 * @brief returns the element from position i and j
 * @param i  index for line
 * @param j  index for column
 * @details this function returns the element in the matrix from position i and j. If the element does not exist in the
 * matrix it will return NULL_TELEM
 * @throws out_of_range - It will throw and exception if the position in the matrix is not valid so when the indexes are out of range/bounds
 * @Best_case - θ(1)
 * @Medium_case - θ(n) where n is the number of elements on the column j
 * @Total_case - O(n)
 */
TElem Matrix::element(int i, int j) {
    if (i < 0 || j < 0 || i >= this->nrLines() || j >= this->nrColumns()) {
        throw std::out_of_range("Invalid Position for your element");
    }
    int start = columnPointers[j];
    int end = columnPointers[j + 1];

    //start = 1
    //end = 4 - 1 = 3

    for (int k = start; k < end; k++) {
        if (rowIndexes[k] == i)
            return elements[k];
    }

    return NULL_TELEM;
}

/**
 * @brief the function modifies the element on the line_vec i and column_vec j
 * @params: i - index for row, j - index for column_vec, TElem e - the element to be modified
 * @details This function modifies the element at position (i,j) in the matrix. If the element exists, it replaces
 * the element with a new value e. If e is NULL_TELEM it deletes the existing element
 * @throws out_of_range if the indices (i,j) are out of range
 * @Best_case - θ(1)
 * @Medium_case - θ(n) where n is the number lines
 * @Total_case - O(n)
 */

//
//TElem Matrix::modify(int i, int j, TElem e) {
//    if (i < 0 || j < 0 || i > this->nrLines() || j > this->nrColumns()) {
//        throw std::out_of_range("Invalid Position for your element");
//    }
//
//    int start = this->columnPointers[j];
//    int end = this->columnPointers[j + 1];
//    TElem old = NULL_TELEM;
//
//    while(start < end) {
//        if(this->rowIndexes[start] == i) {
//            old = this->elements[start];
//            if(e != NULL_TELEM) {
//                this->elements[start] = e;
//            }
//            else {
//                this->deleteFromPosition(start, j);
//            }
//            return old;
//        }
//
//        if(this->rowIndexes[start] > i) {
//            old = this->elements[start];
//
//            this->addToPosition(start, i, j, e);
//
//            return old;
//        }
//
//        start++;
//    }
//
//    this->addToPosition(start, i, j, e);
//    return NULL_TELEM;
//
//}

TElem Matrix::modify(int i, int j, TElem e) {
    if (i < 0 || j < 0 || i > this->nrLines() || j > this->nrColumns()) {
        throw std::out_of_range("Invalid Position for your element");
    }


    int start = this->columnPointers[j];
    int end = this->columnPointers[j + 1];
    TElem old = NULL_TELEM;

    for (int idx = start; idx < end; idx++) {
        if (this->rowIndexes[idx] == i) {
            old = this->elements[idx];
            if (e != NULL_TELEM) {
                this->elements[idx] = e;
            } else {
                this->deleteFromPosition(idx, j);
            }
            return old;
        }

        if (this->rowIndexes[idx] > i) {
            old = this->elements[idx];
            this->addToPosition(idx, i, j, e);
            return old;
        }
    }

    this->addToPosition(end, i, j, e);
    return NULL_TELEM;
}

void Matrix::print() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            int start = columnPointers[j];
            int end = columnPointers[j + 1];

            bool found = false;
            for (int k = start; k < end; k++) {
                if (rowIndexes[k] == i) {
                    std::cout << elements[k] << " ";
                    found = true;
                    break;
                }
            }

            if (!found) {
                std::cout << "0 ";
            }
        }
        std::cout << std::endl;
    }
}

void Matrix::resizeRowIndexes(int newCapacity) {
    if (newCapacity < rowSize)
        throw std::out_of_range("Index out of range");

    int *newArray = new int[newCapacity];
    for (int i = 0; i < rowSize; i++)
        newArray[i] = this->rowIndexes[i];

    delete[] this->rowIndexes;
    this->rowIndexes = newArray;
    this->rowCapacity = newCapacity;
}

void Matrix::resizeElements(int newCapacity) {
    if (newCapacity < elementsSize)
        throw std::out_of_range("Index out of range");

    auto *newArray = new TElem[newCapacity];
    for (int i = 0; i < elementsSize; i++)
        newArray[i] = elements[i];

    delete[] elements;
    elements = newArray;
    elementsCapacity = newCapacity;
}

void Matrix::automaticResizeRowIndexes() {
    if (rowSize == rowCapacity)
        resizeRowIndexes(rowCapacity * 2);
    else if (rowSize <= rowCapacity / 4 && rowCapacity >= 10)
        resizeRowIndexes(rowCapacity / 2);
}

void Matrix::automaticElementsIndexes() {
    if (elementsSize == elementsCapacity)
        resizeElements(elementsCapacity * 2);
    if (elementsSize == elementsCapacity / 4 && elementsCapacity >= 10)
        resizeElements(this->elementsCapacity / 2);
}

/**
 * @brief The destructor function for the Matrix class
 * @details it frees the memory allocated for the arrays elements, rowIndex and columnPointers
 */
Matrix::~Matrix() {
    delete[] this->elements;
    delete[] this->rowIndexes;
    delete[] this->columnPointers;
}

/**
 * @brief used to dynamically resize the arrays
 * @details this function is called when the number of elements in the matrix exceeds the capacity
// */
//void Matrix::resize() {
//
//    auto newRowIndexes = new TElem[2 * this->rowCapacity];
//    auto new_elements = new TElem[2 * this->rowCapacity];
//
//    for(int i = 0; i < this->rowSize; i++) {
//        newRowIndexes[i] = this->rowIndexes[i];
//        new_elements[i] = this->elements[i];
//    }
//    delete[] this->elements;
//    delete[] this->rowIndexes;
//
//    this->rowCapacity *= 2;
//    this->elements = new_elements;
//    this->rowIndexes = newRowIndexes;
//}




/**
 * @brief function to adds an element to a certain position, used for the modify function
 * @details if the number of rows is equal to the capacity, it calls the resize function to increase
 * the capacity of the matrix. It then shifts the elements to the right of position 'position' by one index
 * and increments their column pointer values by one.
 * It then updates the rowIndexes and elements arrays at the specified new position
 * @param position - the position where the element e should be added
 * @param i - index for row i
 * @param j - index for column j
 * @param e - element to be added to the array
 */
void Matrix::addToPosition(int position, int i, int j, TElem e) {
    if (this->rowSize == this->rowCapacity) {
        this->automaticResizeRowIndexes();
        this->automaticElementsIndexes();

    }
    this->rowSize++;

    for(int index = this->rowSize - 1; index > position; index--){
        this->rowIndexes[index] = this->rowIndexes[index - 1];
        this->elements[index] = this->elements[index-1];
    }

    for(int index = j + 1; index < this->columns + 1; index++)
        this->columnPointers[index]++;

    this->rowIndexes[position] = i;
    this->elements[position] = e;

}

/**
 * @brief function to delete an element at a certain position, used for the modify function
 * @details if the number of rows is equal to the capacity, it calls the resize function to increase
 * the capacity of the matrix. It deletes the element at position 'position' from the matrix that belongs
 * to column j. It then shift all the elements to the right of position to the legt by one index
 * and then decrements the the column pointers of the values one by one
 * It then updates the rowSize and elements arrays accordingly.
 * It then updates the rowIndexes and elements arrays at the specified new position
 * @param position - the position where the element e should be added
 * @param j - index for column j
 */
void Matrix::deleteFromPosition(int position, int j) {
    for(int index = position; index < this->rowSize - 1; index++) {
        this->rowIndexes[index] = this->rowIndexes[index + 1];
        this->elements[index] = this->elements[index + 1];
    }
    this->rowSize--;
    automaticResizeRowIndexes();
    automaticElementsIndexes();

    for(int index = j + 1; index < this->columns + 1; index++) {
        this->columnPointers[index]--;
    }


}




Matrix* Matrix::add(const Matrix& matrix) const {
    if (this->nrColumns() != matrix.nrColumns() || this->nrLines() != matrix.nrLines()) {
        throw std::invalid_argument("Matrices should have the same size.");
    }
    auto* result = new Matrix(this->nrLines(), this->nrColumns());

    for (int j = 0; j < this->nrColumns(); j++) {
        int thisStart = this->columnPointers[j];
        int matrixStart = matrix.columnPointers[j];
        int resultStart = result->columnPointers[j];

        int thisEnd = this->columnPointers[j + 1];
        int matrixEnd = matrix.columnPointers[j + 1];
        int resultEnd = result->columnPointers[j + 1];

        int thisRow = 0;
        int matrixRow = 0;

        while (thisStart < thisEnd && matrixStart < matrixEnd) {
            if (this->rowIndexes[thisStart] == matrix.rowIndexes[matrixStart]) {
                int value = this->elements[thisStart] + matrix.elements[matrixStart];
                if (value != 0) {
                    result->rowIndexes[resultStart] = this->rowIndexes[thisStart];
                    result->elements[resultStart] = value;
                    resultStart++;
                }
                thisStart++;
                matrixStart++;
            } else if (this->rowIndexes[thisStart] < matrix.rowIndexes[matrixStart]) {
                result->rowIndexes[resultStart] = this->rowIndexes[thisStart];
                result->elements[resultStart] = this->elements[thisStart];
                resultStart++;
                thisStart++;
            } else {
                result->rowIndexes[resultStart] = matrix.rowIndexes[matrixStart];
                result->elements[resultStart] = matrix.elements[matrixStart];
                resultStart++;
                matrixStart++;
            }
        }

        while (thisStart < thisEnd) {
            result->rowIndexes[resultStart] = this->rowIndexes[thisStart];
            result->elements[resultStart] = this->elements[thisStart];
            resultStart++;
            thisStart++;
        }

        while (matrixStart < matrixEnd) {
            result->rowIndexes[resultStart] = matrix.rowIndexes[matrixStart];
            result->elements[resultStart] = matrix.elements[matrixStart];
            resultStart++;
            matrixStart++;
        }

        result->columnPointers[j + 1] = resultStart;
    }

    result->elementsSize = result->columnPointers[this->nrColumns()];

    return result;
}



Matrix Matrix::subtract(const Matrix& m) {
    if (m.nrLines() != this->nrLines() || m.nrColumns() != this->nrColumns()) {
        throw std::out_of_range("Matrices have different sizes");
    }

    Matrix result(this->nrLines(), this->nrColumns());

    for (int j = 0; j < this->nrColumns(); j++) {
        int startThis = this->columnPointers[j];
        int endThis = this->columnPointers[j + 1];
        int startM = m.columnPointers[j];
        int endM = m.columnPointers[j + 1];
        int iThis = startThis;
        int iM = startM;

        while (iThis < endThis && iM < endM) {
            int rowThis = this->rowIndexes[iThis];
            int rowM = m.rowIndexes[iM];
            if (rowThis == rowM) {
                TElem value = this->elements[iThis] - m.elements[iM];
                if (value != NULL_TELEM) {
                    result.addToPosition(result.elementsSize, rowThis, j, value);
                }
                iThis++;
                iM++;
            } else if (rowThis < rowM) {
                result.addToPosition(result.elementsSize, rowThis, j, this->elements[iThis]);
                iThis++;
            } else {
                result.addToPosition(result.elementsSize, rowM, j, -m.elements[iM]);
                iM++;
            }
        }

        while (iThis < endThis) {
            int rowThis = this->rowIndexes[iThis];
            result.addToPosition(result.elementsSize, rowThis, j, this->elements[iThis]);
            iThis++;
        }

        while (iM < endM) {
            int rowM = m.rowIndexes[iM];
            result.addToPosition(result.elementsSize, rowM, j, -m.elements[iM]);
            iM++;
        }
    }

    return result;
}




//void Matrix::transpose() {
//    auto* transposed = new Matrix(this->columns, this->rows);
//
//    //check to see if the matrix is a square matrix
//
//    for (int j = 0; j < this->columns; j++) {
//        for (int i = this->columnPointers[j]; i < this->columnPointers[j + 1]; i++) {
//            transposed->addToPosition(transposed->columnPointers[rowIndexes[i] + 1], j, rowIndexes[i], elements[i]);
//        }
//    }
//
//    this->columns = transposed->columns;
//    this->rows = transposed->rows;
//    this->rowCapacity = transposed->rowCapacity;
//    this->rowSize = transposed->rowSize;
//    this->elementsSize = transposed->elementsSize;
//    delete[] this->columnPointers;
//    delete[] this->rowIndexes;
//    delete[] this->elements;
//    this->columnPointers = transposed->columnPointers;
//    this->rowIndexes = transposed->rowIndexes;
//    this->elements = transposed->elements;
//
//    transposed->columnPointers = nullptr;
//    transposed->rowIndexes = nullptr;
//    transposed->elements = nullptr;
//    delete transposed;
//}
//
//void Matrix::transpose(int i, int j) {
//    for(int i = rows; rows < i; rows++) {
//        for(int col = 0; col < rows; col++) {
//            this->modify(i, j, this->element(j, j));
//        }
//    }
//}

//void Matrix::transpose() {
//    if (rows == columns) { // squared matrix
//        for (int i = 0; i < rows; i++) {
//            for (int j = i + 1; j < columns; j++) {
//                int pos1 = columnPointers[i];
//                int pos2 = columnPointers[j];
//                while (pos1 < columnPointers[i + 1] && pos2 < columnPointers[j + 1]) {
//                    if (rowIndexes[pos1] == j && rowIndexes[pos2] == i) {
//                        // swap elements
//                        TElem temp = elements[pos1];
//                        elements[pos1] = elements[pos2];
//                        elements[pos2] = temp;
//
//                        // swap row indices
//                        rowIndexes[pos1] = i;
//                        rowIndexes[pos2] = j;
//
//                        pos1++;
//                        pos2++;
//                    } else if (rowIndexes[pos1] < rowIndexes[pos2] || (rowIndexes[pos1] == rowIndexes[pos2] && i < j)) {
//                        pos1++;
//                    } else {
//                        pos2++;
//                    }
//                }
//            }
//        }
//    } else { // non-squared matrix
//        Matrix* transposed = new Matrix(columns, rows);
//        for (int i = 0; i < columns; i++) {
//            for (int j = columnPointers[i]; j < columnPointers[i + 1]; j++) {
//                transposed->addToPosition(rowIndexes[j], i, elements[j]);
//            }
//        }
//        *this = *transposed;
//        delete transposed;
//    }
//}


//void Matrix::transpose() {
//
//    if (this->nrLines() != this->nrColumns()) {
//        // Non-square matrix transpose
//        int *new_columnPointers = new int[this->rows + 1]{};
//        int *new_rowIndexes = new int[this->elementsSize]{};
//        TElem *new_elements = new TElem[this->elementsSize]{};
//
//        // Count the number of elements in each row
//        for (int i = 0; i < this->elementsSize; i++) {
//            new_columnPointers[this->rowIndexes[i] + 1]++;
//        }
//
//        // Compute the starting position of each row
//        for (int i = 1; i <= this->rows; i++) {
//            new_columnPointers[i] += new_columnPointers[i - 1];
//        }
//
//        // Transpose the matrix
//        for (int j = 0; j < this->columns; j++) {
//            int start = this->columnPointers[j];
//            int end = this->columnPointers[j + 1];
//
//            for (int k = start; k < end; k++) {
//                int i = this->rowIndexes[k];
//                int pos = new_columnPointers[i];
//                new_rowIndexes[pos] = j;
//                new_elements[pos] = this->elements[k];
//                new_columnPointers[i]++;
//            }
//        }
//
//        // Restore the column pointers array
//        for (int i = this->rows; i > 0; i--) {
//            new_columnPointers[i] = new_columnPointers[i - 1];
//        }
//        new_columnPointers[0] = 0;
//
//        // Update the matrix
//        delete[] this->columnPointers;
//        delete[] this->rowIndexes;
//        delete[] this->elements;
//
//        this->columnPointers = new_columnPointers;
//        this->rowIndexes = new_rowIndexes;
//        this->elements = new_elements;
//    } else {
//        // Square matrix transpose
//        for (int i = 0; i < this->rows; i++) {
//            for (int j = i + 1; j < this->columns; j++) {
//                int pos1 = this->columnPointers[i];
//                int pos2 = this->columnPointers[j];
//                int end1 = this->columnPointers[i + 1];
//                int end2 = this->columnPointers[j + 1];
//
//                while (pos1 < end1 && pos2 < end2) {
//                    if (this->rowIndexes[pos1] < this->rowIndexes[pos2]) {
//                        pos1++;
//                    } else if (this->rowIndexes[pos1] > this->rowIndexes[pos2]) {
//                        int temp = this->rowIndexes[pos2];
//                        this->rowIndexes[pos2] = this->rowIndexes[pos1];
//                        this->rowIndexes[pos1] = temp;
//
//                        temp = this->elements[pos2];
//                        this->elements[pos2] = this->elements[pos1];
//                        this->elements[pos1] = temp;
//
//                        pos1++;
//                        pos2++;
//                    } else {
//                        pos1++;
//                        pos2++;
//                    }
//                }
//            }
//        }
//    }
//}

//void Matrix::transpose() {
//
//    // Check if matrix is squared
//    if (this->nrLines() == this->nrColumns()) {
//
//        // Squared matrix transpose
//        for (int i = 0; i < this->rows; i++) {
//            for (int j = i+1; j < this->columns; j++) {
//                TElem temp = this->element(i,j);
//                this->addToPosition(this->columnPointers[j], j, i, temp);
//                this->deleteFromPosition(this->columnPointers[j+1], j);
//                temp = this->element(j,i);
//                this->addToPosition(this->columnPointers[i], i, j, temp);
//                this->deleteFromPosition(this->columnPointers[i+1], i);
//            }
//        }
//        int temp = this->rows;
//        this->rows = this->columns;
//        this->columns = temp;
//    }
//    else {
//
//        // Non-squared matrix transpose
//        int* rowCounts = new int[this->columns];
//        for (int i = 0; i < this->columns; i++) {
//            rowCounts[i] = 0;
//        }
//        for (int i = 0; i < this->rowSize; i++) {
//            rowCounts[this->rowIndexes[i]]++;
//        }
//        int* newRowIndexes = new int[this->rowSize];
//        int* newColumnPointers = new int[this->rows + 1];
//
//        // Calculate new column pointers
//        newColumnPointers[0] = 0;
//        for (int i = 0; i < this->columns; i++) {
//            newColumnPointers[i+1] = newColumnPointers[i] + rowCounts[i];
//        }
//
//        // Calculate new row indexes
//        for (int i = 0; i < this->rows; i++) {
//            for (int j = columnPointers[i]; j < columnPointers[i+1]; j++) {
//                int col = i;
//                int row = rowIndexes[j];
//                int dest = newColumnPointers[row];
//                newRowIndexes[dest] = col;
//                newColumnPointers[row]++;
//            }
//        }
//
//        // Swap row and column sizes
//        int temp = this->rows;
//        this->rows = this->columns;
//        this->columns = temp;
//
//        // Update matrix values
//        int* tempRowIndexes = this->rowIndexes;
//        int* tempColumnPointers = this->columnPointers;
//        this->rowIndexes = newRowIndexes;
//        this->columnPointers = newColumnPointers;
//        delete[] tempRowIndexes;
//        delete[] tempColumnPointers;
//    }
//}


void Matrix::transpose() {
    auto* transposed = new Matrix(this->columns, this->rows);

    //check to see if the matrix is a square matrix

    for (int j = 0; j < this->columns; j++) {
        for (int i = this->columnPointers[j]; i < this->columnPointers[j + 1]; i++) {
            transposed->addToPosition(transposed->columnPointers[rowIndexes[i] + 1], j, rowIndexes[i], elements[i]);
        }
    }

    this->columns = transposed->columns;
    this->rows = transposed->rows;
    this->rowCapacity = transposed->rowCapacity;
    this->rowSize = transposed->rowSize;
    this->elementsSize = transposed->elementsSize;
    delete[] this->columnPointers;
    delete[] this->rowIndexes;
    delete[] this->elements;
    this->columnPointers = transposed->columnPointers;
    this->rowIndexes = transposed->rowIndexes;
    this->elements = transposed->elements;

    transposed->columnPointers = nullptr;
    transposed->rowIndexes = nullptr;
    transposed->elements = nullptr;
    delete transposed;
}