#pragma once

void testAll();
void testMapInterval();

