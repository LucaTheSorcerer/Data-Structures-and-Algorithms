#include "Matrix.h"
#include <exception>

/**
 * @brief constructor for the Matrix class
 * @details: the constructor receives the number of lines and columns of the matrix as parameters and initializes
 * the matrix with the given dimensions.
 * @param nrLines number of lines of the matrix
 * @param nrCols number of columns of the matrix
 * @throws exception if the dimensions are invalid
 * @TimeComplexity-BestCase: θ(n + m)
 * @TimeComplexity-AverageCase: θ(n + m)
 * @TimeComplexity-WorstCase: θ(n + m)
 * @note n = nrLines, m = nrCols, the time complexity is dominated by the createHeaderNodes() function
 *
 */
Matrix::Matrix(int nrLines, int nrCols) {
    if (nrLines <= 0 || nrCols <= 0)
        throw std::out_of_range("Invalid dimensions");

    lines = nrLines;
    columns = nrCols;
    // 1 = head, nrLines+nrCols = head Nodes, 10 matrix elements
    capacity = 1 + nrLines + nrCols + 10;
    size = 0;
    head = 0; // Index of head node (-1, -1) in nodes array
    firstEmpty = -1;

    nodes = new Node[capacity];

    createHeaderNodes();

}

/**
 * @brief function that creates the necessary header nodes for a circular sparse matrix.
 * @details: the head is initialized with the index position (-1,-1). The head node is the top-left corner of the matrix
 * It does not store any element value but acts as a sentinel node to simplify the algorithms that manipulate the matrix
 * The initialization of the header node distinguishes is from the regular matrix columns and lines nodes
 * Then there are header nodes for lines created. The first loop iterates over the lines of the matrix and for each line
 * it creates a header node with the index arrIdx, which stores the line index, the index of the next line header and
 * the index of the first non-zero element of the line. The arrIdx is incremented after each iteration to keep track of
 * the next available index for a header node.
 * With the second for loop we iterate over the columns of the matrix. For each column, it creates a header node with
 * index arrIdx which stores the column index, the index of the next column header and the index of the first non-zero
 * element of the column. The arrIdx is incremented after each iteration to keep track of the next available index for
 * a header node.
 * @TimeComplexity-BestCase θ(n + m)
 * @TimeComplexity-AverageCase θ(n + m)
 * @TimeComplexity-WorstCase θ(n + m)
 * @note n = number of lines, m = number of columns
 */
void Matrix::createHeaderNodes() {
    nodes[head].line = -1;
    nodes[head].column = -1;
    nodes[head].nextLine = 1; // first line header (0, -1)
    nodes[head].nextColumn = 1 + lines; // first column header (-1, 0)

    // Create header nodes for lines
    int arrIdx = 1;
    for (int line = 0; line < lines; line++) {
        nodes[arrIdx].line = line;
        nodes[arrIdx].nextLine = arrIdx + 1;
        nodes[arrIdx].nextColumn = arrIdx;
        arrIdx++;
    }

    // Last row head points to head(-1,-1)
    nodes[arrIdx - 1].nextLine = head;

    // Create header nodes for columns
    for (int col = 0; col < columns; col++) {
        nodes[arrIdx].column = col;
        nodes[arrIdx].nextColumn = arrIdx + 1;
        nodes[arrIdx].nextLine = arrIdx;
        arrIdx++;
    }

    // Last column head points to head(-1,-1)
    nodes[arrIdx - 1].nextColumn = head;

    size = arrIdx;
}

/**
 * @brief function that returns the number of lines of the matrix
 * @return line - number of lines
 * @TimeComplexity-BestCase θ(1)
 * @TimeComplexity-AverageCase θ(1)
 * @TimeComplexity-WorstCase θ(1)
 */
int Matrix::nrLines() const {
    return lines;
}

/**
 * @brief function that returns the number of columns of the matrix
 * @return column - number of columns
 * @TimeComplexity-BestCase θ(1)
 * @TimeComplexity-AverageCase θ(1)
 * @TimeComplexity-WorstCase θ(1)
 */
int Matrix::nrColumns() const {
    return columns;
}


/**
 * @brief function that returns the element from the given position (i,j) of the matrix
 * @details the function first checks if the specified position is valid. If it is not, it throws an exception. This is
 * to ensure that the indices are valid and that the function does not try to access elements outside the matrix.
 * Next the function initializes a variable curr to the index of the first node in the matrix.
 * The first while loop iterates over the nodes until it find the node with line equal to 'i'.
 * The next while loop iterates over the nodes starting at the node with line equal to 'i' until it finds the node with
 * column equal to 'j'. If the node with column j is found, the function returns the value of the node, because it means
 * that the element (i,j) exists in the matrix. If the node with column j is not found, it means that the element (i,j)
 * does not exist in the matrix, so the function returns NULL_TELEM.
 * @param i - line index
 * @param j - column index
 * @return value of the element (i,j) if it exists in the matrix, NULL_TELEM otherwise
 * @throws exception if the indexes are invalid
 * @TimeComplexity-BestCase θ(1) - the element is the first element in the matrix
 * @TimeComplexity-AverageCase θ(n) - the element is in the middle of the matrix
 * @TimeComplexity-WorstCase θ(n) - the element is the last element in the matrix
 * @note n = number of elements in the matrix
 */

TElem Matrix::element(int i, int j) const {
    if (i < 0 || i >= lines || j < 0 || j >= columns)
        throw std::invalid_argument("Invalid indexes!");

    int curr = nodes[head].nextLine;

    // curr = index of the first node in line i
    while (nodes[curr].line != i) {
        curr = nodes[curr].nextLine;
    }

    // curr = index of node(i, j) || head
    while (nodes[nodes[curr].nextColumn].column != -1) {
        if (nodes[curr].nextColumn >= capacity) {
            throw std::out_of_range("Index out of range");
        }
        curr = nodes[curr].nextColumn;
        if (nodes[curr].column == j)
            return nodes[curr].value;
    }

    return NULL_TELEM;
}

//TElem Matrix::element(int i, int j) const {
//    if (i < 0 || i >= lines || j < 0 || j >= columns)
//        throw std::exception();
//
//    Node *curr = &nodes[head];
//
//    // curr = header node for line i
//    while (curr->line != i) {
//        curr = &nodes[curr->nextLine];
////        cout << "curr.line = " << curr->line << endl;
//    }
//
//    // curr = node(i, j) || head
//    while (nodes[curr->nextColumn].column != -1) {
//        if (curr->nextColumn >= capacity) {
//            throw std::out_of_range("Index out of range");
//        }
//        curr = &nodes[curr->nextColumn];
//        if (curr->column == j)
//            return curr->value;
//    }
//
//    return NULL_TELEM;
//}


/**
 * @brief function that modifies the element from the given position (i,j) and returns the previous value from that
 * position
 * @param i
 * @param j
 * @param e
 * @return
 */
TElem Matrix::modify(int i, int j, TElem e) {
    if (i < 0 || i >= lines || j < 0 || j >= columns)
        throw std::exception();

    int curr = head;

    // Find the header node for line i
    while (nodes[curr].line != i) {
        curr = nodes[curr].nextLine;
    }

    int prev = curr;

    // Find the node with column j in line i, or the node before where it should be
    while (nodes[curr].column != -1 && nodes[curr].column <= j) {
        if (curr >= capacity) {
            throw std::out_of_range("Index out of range");
        }
        prev = curr;
        curr = nodes[curr].nextColumn;
    }

    // If the node doesn't exist, create it
    if (nodes[curr].column != j) {
        // If there are no more empty nodes, resize the array
        if (firstEmpty == -1)
            automaticResize();

        int newIdx = firstEmpty;
        firstEmpty = nodes[firstEmpty].nextColumn;

        nodes[newIdx].line = i;
        nodes[newIdx].column = j;
        nodes[newIdx].nextLine = curr;
        nodes[newIdx].nextColumn = nodes[prev].nextColumn;
        nodes[prev].nextColumn = newIdx;

        size++;
        curr = newIdx;
    }

    // Update the value of the node and return the old value
    TElem oldValue = nodes[curr].value;
    nodes[curr].value = e;
    return oldValue;
}






Matrix::~Matrix() {
    delete[] nodes;
}

void Matrix::automaticResize() {
    if (firstEmpty == -1)
        resize(capacity * 2);
    else if (size <= capacity / 4 && capacity >= 10)
        resize(capacity / 2);
}

void Matrix::resize(int newCapacity) {
    if (newCapacity < size)
        throw std::invalid_argument("New capacity cannot be smaller than the actual size");

    Node *newNodes = new Node[newCapacity];

    for (int i = 0; i < std::min(capacity,newCapacity); ++i) {
        newNodes[i] = nodes[i];
    }

    for (int i = capacity; i < newCapacity; ++i) {
        newNodes[i].nextLine = i + 1;
        newNodes[i].nextColumn = i + 1;
    }

    newNodes[newCapacity - 1].nextLine = -1;
    newNodes[newCapacity - 1].nextColumn = -1;

    firstEmpty = capacity;

    capacity = newCapacity;

    delete[] nodes;

    nodes = newNodes;
}

void Matrix::print() const {
    for (int i = 0; i < lines; ++i) {
        for (int j = 0; j < columns; ++j) {
            std::cout << this->element(i, j) << " ";
        }
        std::cout << std::endl;
    }
}
