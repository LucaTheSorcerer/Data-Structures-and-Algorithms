#include "Set.h"
#include "SetITerator.h"
using namespace std;
#include <exception>

Set::Set() {
	this->capacity = 16; //set the default capacity to 16
    this->numElements = 0; //initially, the set is empty
    this->bitArray = new bool[this->capacity]; // allocation
    this->startInt = 1; //setting the beginning of the interval
    this->finalInt = 0; //setting the end of the interval
    //initialising the bitarray with false values
    for (int i = 0; i < this->capacity; i++){
        this->bitArray[i] = false;
    }
}

//This operation adds an element to the set. The worst case time
//complexity is O(n) (n is the size of the bitArray), because in
//the worst case, we need to resize the bitArray in order to add
//the element. Best case is O(1), when we don't need to resize.
//The average case is Θ(n) when resizing is needed.
bool Set::add(TElem elem) {
    if (elem < this->startInt || elem > this->finalInt) {
        //update the interval and the bit array
        int newStartInt = this->startInt;
        int newFinalInt = this->finalInt;
        if (elem < this->startInt) {
            newStartInt = elem;
        }
        if (elem > this->finalInt) {
            newFinalInt = elem;
        }
        //we know compute the interval [0, x-1]
        int x = newFinalInt - newStartInt + 1;
        bool* newBitArray = new bool[x];
        for (int i = 0; i < x; i++) {
            if (i == elem - newStartInt) {
                newBitArray[i] = true;
            } else if (i < (this->finalInt - this->startInt + 1)) {
                newBitArray[i] = this->bitArray[i];
            } else {
                newBitArray[i] = false;
            }
        }
        delete[] this->bitArray;
        this->bitArray = newBitArray;
        this->startInt = newStartInt;
        this->finalInt = newFinalInt;
        this->numElements++;
        return true;
    }
    else {
        int index = elem - this->startInt;
        if (this->bitArray[index] == false) {
            this->bitArray[index] = true;
            this->numElements++;
            return true;
        }
        else {
            return false;
        }
    }
}

//This operation removes an element from the set. The worst case
//complexity is O(n), because we may need to resize the array if
//remove the first or last element. The best case is O(1) when the
//element that gets removed is the first or the last, and we don't
//have to resize. In general the complexity is Θ(n) when we need
//to resize.
bool Set::remove(TElem elem) {
    if (elem >= this->startInt && elem <= this->finalInt) {
        int index = elem - this->startInt;
        if (this->bitArray[index] == true) {
            this->bitArray[index] = false;
            this->numElements--;
            //check if the interval of values needs to be updated
            if (elem == this->startInt) {
                while (!this->bitArray[0] && this->startInt < this->finalInt) {
                    this->startInt++;
                }
            }
            if (elem == this->finalInt) {
                while (!this->bitArray[this->finalInt - this->startInt]
                && this->startInt < this->finalInt) {
                    this->finalInt--;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

//Worst case and best case scenarios are both O(1) because we
//access the bitArray to check if the element is there or not.
//The average case complexity is Θ(1).
bool Set::search(TElem elem) const {
    if (elem >= this->startInt && elem <= this->finalInt) {
        int index = elem - this->startInt + 1;
        return this->bitArray[index];
    }
    else {
        return false;
    }
}

//Complexity is Θ(1).
int Set::size() const {
	return this->numElements;
}

//Complexity is Θ(1).
bool Set::isEmpty() const {
	return this->numElements == 0;
}


Set::~Set() {
	delete[] this->bitArray;
}

//Complexity is Θ(1).
SetIterator Set::iterator() const {
	return SetIterator(*this);
}


//void Set::resize() {
//    int newCapacity = capacity * 2;
//    bool* newBitArray = new bool[newCapacity];
//
//    //Copy elements from olf bit array to new bit array
//    for (int i = 0; i < capacity; i++) {
//        newBitArray[i] = bitArray[i];
//    }
//    //Make sure the new positions are all zeros for now
//    for (int i = capacity; i < newCapacity; i++) {
//        newBitArray[i] = false;
//    }
//    //Deallocate old bit array
//    delete[] bitArray;
//
//    //Update bit array and capacity
//    bitArray = newBitArray;
//    capacity = newCapacity;
//}
