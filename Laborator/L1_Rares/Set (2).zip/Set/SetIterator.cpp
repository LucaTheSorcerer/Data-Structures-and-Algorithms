#include "SetIterator.h"
#include "Set.h"
#include <exception>
#include <stdexcept>

SetIterator::SetIterator(const Set& m) : set(m)
{
    this->currentPosition = 0;
}


void SetIterator::first() {
    this->currentPosition = 0;
    this->next();
}


void SetIterator::next() {
    if (!valid()) {
        throw std::runtime_error("Invalid iterator");
    }
    this->currentPosition++;
    while (this->currentPosition < set.capacity && !set.bitArray[this->currentPosition]) {
        this->currentPosition++;
    }
}


TElem SetIterator::getCurrent()
{
    if (!valid()) {
        throw std::runtime_error("Invalid iterator");
    }
    return this->currentPosition + set.startInt;
}

bool SetIterator::valid() const {
    return this->currentPosition >= 0 && this->currentPosition < set.finalInt - set.startInt;
}



