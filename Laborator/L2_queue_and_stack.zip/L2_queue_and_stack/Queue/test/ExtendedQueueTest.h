#pragma once

void testAllExtendedQueue();