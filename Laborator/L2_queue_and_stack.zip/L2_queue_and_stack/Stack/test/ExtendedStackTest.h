//
// Created by Luca Tudor on 10.04.2023.
//

#pragma once

void testAllExtendedStack();
