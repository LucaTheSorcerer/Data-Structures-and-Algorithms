//
// Created by Luca Tudor on 15.04.2023.
//

#pragma once

void test_shunting_yard_small();
void test_shunting_yard_bigger();
void test_shunting_yard_even_bigger();